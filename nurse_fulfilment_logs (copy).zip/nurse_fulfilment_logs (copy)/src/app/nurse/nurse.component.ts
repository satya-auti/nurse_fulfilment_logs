import { Component, OnInit } from '@angular/core';
import { NurseService } from './nurse.service';

@Component({
  selector: 'app-nurse',
  templateUrl: './nurse.component.html',
  styleUrls: ['./nurse.component.scss'],
})
export class NurseComponent implements OnInit {
  constructor(private nurseService: NurseService) {}

  nurseLogs: any = [];
  ngOnInit(): void {
    this.nurseLogs = this.nurseService.nurseLogs;
    // const data = this.nurseService.exportAsExcelFile(this.nurseLogs, 'sample');
    console.log('this.nurseLogs', this.nurseLogs);
    // console.log('data', data);

    return this.nurseService.nurseLogs;
  }

  downloadExcelFile() {
    // return this.nurseService.exportAsExcelFile(this.nurseLogs, 'sample');
    return this.nurseService.exportTable();
  }

  // this.nurseService.exportAsExcelFile(excelJsonData, 'sample');
}
