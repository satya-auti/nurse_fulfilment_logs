import { Injectable } from '@angular/core';
import * as fileSaver from 'file-saver';
import * as XLSX from 'xlsx';

@Injectable({
  providedIn: 'root',
})
export class NurseService {
  constructor() {}
  EXCEL_TYPE =
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  EXCEL_EXTENSION = '.xlsx';

  nurseLogs: any = [
    { nurseId: 1, nurseName: 'Kavita Kale', nurseComment: 'abc' },
    { nurseId: 2, nurseName: 'Urmi Shinde', nurseComment: 'def' },
    { nurseId: 3, nurseName: 'Akshada Gore', nurseComment: 'xyz' },
    { nurseId: 4, nurseName: 'Renuka Mahajan', nurseComment: 'pqr' },
    { nurseId: 5, nurseName: 'Yasmin Jamadar', nurseComment: 'lmn' },
    { nurseId: 6, nurseName: 'Rani Uchale', nurseComment: 'tuv' },
    { nurseId: 7, nurseName: 'Amita Waman', nurseComment: 'ghi' },
    { nurseId: 8, nurseName: 'Chhaya Balwadkar', nurseComment: 'opq' },
    { nurseId: 9, nurseName: 'Sayali Hadawale', nurseComment: 'rst' },
  ];

  exportTable() {
    let newArray: any[] = [];
    let data = Object.values(this.nurseLogs);
    // Object.keys(data).forEach((key, index) => {
    //   console.log('data ext', data);

    //   // newArray.push({
    //   //   'Ind. ID': data[key].individual_id,
    //   //   'HH ID': data[key].hh_id,
    //   //   'Name(en)':
    //   //     data[key].ind_first_name_en + ' ' + data[key].ind_last_name_en,
    //   //   'Name(ar)':
    //   //     data[key].ind_first_name_ar + ' ' + data[key].ind_last_name_ar,
    //   //   UID: data[key].uId,
    //   //   Gender: data[key].ind_gender,
    //   //   'D.O.B': data[key].dob,
    //   //   'Head Of HH': data[key].head_of_hh,
    //   //   'Phone Number': data[key].phone,
    //   //   Status: data[key].ind_status,
    //   //   'User ID': data[key].user_id,
    //   // });
    // });

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    // const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(newArray);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'All Ind. Searched Data Export');

    /* save to file */
    // XLSX.writeFile(wb, 'ExportAllData' + new Date().getTime() + '.xlsx');
    XLSX.writeFile(
      wb,
      'ExportAllData' + new Date().getTime() + this.EXCEL_EXTENSION
    );
  }
}

// }
